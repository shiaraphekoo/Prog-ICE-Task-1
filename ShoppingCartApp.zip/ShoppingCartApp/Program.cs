﻿namespace program;
public enum ProductCategory //declare enum variables
{
    Clothing,
    Electronics,
    Home,
    Beauty,
    Groceries
}
internal class Program
{
    static void Main(string[] args) //main method
    {
        Console.WriteLine("Enter product name:");
        string name = Console.ReadLine();

        Console.WriteLine("Enter product price:");
        double price = double.Parse(Console.ReadLine());

        Console.WriteLine("Enter product category:");
        string category = Console.ReadLine();


    }
}
