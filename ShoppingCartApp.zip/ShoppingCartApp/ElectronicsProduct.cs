﻿using program;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingCartApp
{

    public class ElectronicsProduct : Product
    {
        private string brand;
        private string model;

        public string Brand
        {
            get { return brand; }
        }

        public string Model
        {
            get { return model; }
        }

        public ElectronicsProduct(string name, double price, ProductCategory category, string brand, string model)
            : base(name, price, category)
        {
            this.brand = brand;
            this.model = model;
        }

        public override void GetInfo()
        {
            Console.WriteLine($"Name: {Name}");
            Console.WriteLine($"Price: {Price}");
            Console.WriteLine($"Category: {Category}");
            Console.WriteLine($"Brand: {brand}");
            Console.WriteLine($"Model: {model}");
        }
    }

    

}

