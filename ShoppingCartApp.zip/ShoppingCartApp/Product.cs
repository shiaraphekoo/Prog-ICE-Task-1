﻿using program;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace ShoppingCartApp
{
    public class Product
    {
        private string name;
        private double price;
        private ProductCategory category;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public double Price
        {
            get { return price; }
            set { price = value; }
        }

        public ProductCategory Category
        {
            get { return category; }
            set { category = value; }
        }

        public Product(string name, double price, ProductCategory category)
        {
            this.name = name;
            this.price = price;
            this.category = category;
        }

        public virtual void GetInfo() //method
        {
            Console.WriteLine($"Name: {name}");
            Console.WriteLine($"Price: {price:C2}"); // Format price as currency
            Console.WriteLine($"Category: {category}");
        }
    }

    public enum ProductCategory
    {
        Clothing,
        Electronics,
        Home,
        Beauty,
        Groceries
    }
}

