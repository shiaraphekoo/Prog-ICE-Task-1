﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingCartApp
{
    internal class ShoppingCart
    {
        private Product[] products;
        private int itemCount;

        public Product[] Products
        {
            get { return products; }
        }

        public int ItemCount
        {
            get { return itemCount; }
        }

        // Constructor with capacity parameter
        public ShoppingCart(int capacity)
        {
            if (capacity <= 0)
            {
                throw new ArgumentException("Capacity must be greater than zero.");
            }
            products = new Product[capacity];
        }

        // Method to add a product to the shopping cart
        public void AddProduct(Product product)
        {
            if (itemCount < products.Length)
            {
                products[itemCount] = product;
                itemCount++;
            }
            else
            {
                Console.WriteLine("Shopping cart is full. Cannot add more products.");
            }
        }

        // Method to remove a product from the shopping cart
        public void RemoveProduct(Product product)
        {
            for (int i = 0; i < itemCount; i++)
            {
                if (products[i] == product)
                {
                    Array.Copy(products, i + 1, products, i, itemCount - i - 1);
                    itemCount--;
                    break;
                }
            }
        }
}
}
