﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingCartApp
{
    internal class ClothingProduct : Product
    {
        private string size;
        private string color;

        // Properties for Size and Color
        public string Size
        {
            get { return size; }
        }

        public string Color
        {
            get { return color; }
        }

        // Constructor
        public ClothingProduct(string name, double price, ProductCategory category, string size, string color)
            : base(name, price, category)
        {
            this.size = size;
            this.color = color;
        }

        // Override method to get information about the clothing product
        public override void GetInfo()
        {
            base.GetInfo(); // Call base class method to print general product info
            Console.WriteLine($"Size: {Size}");
            Console.WriteLine($"Color: {Color}");
        }
    
 
}
}
